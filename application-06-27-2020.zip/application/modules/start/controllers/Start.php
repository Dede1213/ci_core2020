<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Start extends CI_Controller{

  function index()
  {
    
     $this->load->view('v_start');
  }

}
